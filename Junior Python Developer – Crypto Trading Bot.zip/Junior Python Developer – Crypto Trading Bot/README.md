# Binance Futures Testnet Trading Bot

A simple Python trading bot for Binance USDT-M Futures Testnet using the `python-binance` library.

## Features
- Place market and limit orders (buy/sell)
- Command-line interface for user input
- Logging of API requests, responses, and errors
- Easily extendable for advanced order types

## Setup
1. **Clone the repository** (if needed) and navigate to the project directory.
2. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```
3. **Register on Binance Futures Testnet:**
   - Go to [Binance Futures Testnet](https://testnet.binancefuture.com/en/futures/BTCUSDT)
   - Create an account and generate API Key and Secret
4. **Configure API keys:**
   - Open `basic_bot.py`
   - Replace `YOUR_TESTNET_API_KEY` and `YOUR_TESTNET_API_SECRET` with your credentials

## Usage
Run the bot from the command line:
```bash
python basic_bot.py
```
Follow the prompts to enter symbol, side, order type, quantity, and price (for limit orders).

## Logs
All API requests, responses, and errors are logged to `trading_bot.log`.

## Notes
- This bot is for educational purposes and uses Binance Testnet only.
- For real trading, use the mainnet and secure your API keys properly. 