import logging
from binance.client import Client
from binance.enums import *
from binance.exceptions import BinanceAPIException

# Configure logging
logging.basicConfig(
    filename='trading_bot.log',
    level=logging.INFO,
    format='%(asctime)s %(levelname)s %(message)s'
)

class BasicBot:
    def __init__(self, api_key, api_secret, testnet=True):
        self.client = Client(api_key, api_secret)
        if testnet:
            self.client.FUTURES_URL = 'https://testnet.binancefuture.com/fapi'
        logging.info("Initialized Binance Client (Testnet: %s)", testnet)

    def place_order(self, symbol, side, order_type, quantity, price=None):
        try:
            if order_type == 'MARKET':
                order = self.client.futures_create_order(
                    symbol=symbol,
                    side=side,
                    type=ORDER_TYPE_MARKET,
                    quantity=quantity
                )
            elif order_type == 'LIMIT':
                order = self.client.futures_create_order(
                    symbol=symbol,
                    side=side,
                    type=ORDER_TYPE_LIMIT,
                    timeInForce=TIME_IN_FORCE_GTC,
                    quantity=quantity,
                    price=price
                )
            else:
                raise ValueError("Unsupported order type")
            logging.info("Order placed: %s", order)
            return order
        except BinanceAPIException as e:
            logging.error("Binance API Exception: %s", e)
            print(f"API Error: {e}")
        except Exception as e:
            logging.error("General Exception: %s", e)
            print(f"Error: {e}")

def get_user_input():
    symbol = input("Enter symbol (e.g., BTCUSDT): ").upper()
    side = input("Enter side (BUY/SELL): ").upper()
    order_type = input("Order type (MARKET/LIMIT): ").upper()
    quantity = float(input("Quantity: "))
    price = None
    if order_type == 'LIMIT':
        price = float(input("Limit price: "))
    return symbol, side, order_type, quantity, price

if __name__ == "__main__":
    # Replace with your testnet API keys
    API_KEY = 'YOUR_TESTNET_API_KEY'
    API_SECRET = 'YOUR_TESTNET_API_SECRET'

    bot = BasicBot(API_KEY, API_SECRET, testnet=True)
    symbol, side, order_type, quantity, price = get_user_input()
    order = bot.place_order(symbol, side, order_type, quantity, price)
    if order:
        print("Order executed:", order)
    else:
        print("Order failed. Check logs for details.") 